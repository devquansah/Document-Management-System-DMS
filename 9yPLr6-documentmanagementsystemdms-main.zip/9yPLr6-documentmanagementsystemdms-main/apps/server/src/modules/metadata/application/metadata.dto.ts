import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class MetadataCreateDto {
  @IsString()
  @IsOptional()
  key?: string

  @IsString()
  @IsOptional()
  value?: string

  @IsString()
  @IsOptional()
  documentId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class MetadataUpdateDto {
  @IsString()
  @IsOptional()
  key?: string

  @IsString()
  @IsOptional()
  value?: string

  @IsString()
  @IsOptional()
  documentId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
