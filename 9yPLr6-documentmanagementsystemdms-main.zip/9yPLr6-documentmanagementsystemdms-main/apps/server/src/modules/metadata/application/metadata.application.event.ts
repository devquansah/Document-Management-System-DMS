export namespace MetadataApplicationEvent {
  export namespace MetadataCreated {
    export const key = 'metadata.application.metadata.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
