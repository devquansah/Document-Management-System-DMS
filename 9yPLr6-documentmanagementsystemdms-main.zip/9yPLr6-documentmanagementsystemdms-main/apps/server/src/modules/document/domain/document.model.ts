import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Folder } from '../../../modules/folder/domain'

import { Version } from '../../../modules/version/domain'

import { Metadata } from '../../../modules/metadata/domain'

import { Permission } from '../../../modules/permission/domain'

import { Share } from '../../../modules/share/domain'

import { ActivityLog } from '../../../modules/activityLog/domain'

@Entity()
export class Document {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  title?: string

  @Column({ nullable: true })
  content?: string

  @Column({ nullable: true })
  versionId?: string

  @Column({ nullable: true })
  createdById?: string

  @ManyToOne(() => User, parent => parent.documentsAsCreatedBy)
  @JoinColumn({ name: 'createdById' })
  createdBy?: User

  @Column({ nullable: true })
  folderId?: string

  @ManyToOne(() => Folder, parent => parent.documents)
  @JoinColumn({ name: 'folderId' })
  folder?: Folder

  @OneToMany(() => Version, child => child.document)
  versions?: Version[]

  @OneToMany(() => Metadata, child => child.document)
  metadatas?: Metadata[]

  @OneToMany(() => Permission, child => child.document)
  permissions?: Permission[]

  @OneToMany(() => Share, child => child.document)
  shares?: Share[]

  @OneToMany(() => ActivityLog, child => child.document)
  activityLogs?: ActivityLog[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
