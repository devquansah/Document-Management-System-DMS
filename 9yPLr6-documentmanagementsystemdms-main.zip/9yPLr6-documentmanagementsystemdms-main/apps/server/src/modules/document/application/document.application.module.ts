import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { DocumentDomainModule } from '../domain'
import { DocumentController } from './document.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { DocumentByUserController } from './documentByUser.controller'

import { FolderDomainModule } from '../../../modules/folder/domain'

import { DocumentByFolderController } from './documentByFolder.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    DocumentDomainModule,

    UserDomainModule,

    FolderDomainModule,
  ],
  controllers: [
    DocumentController,

    DocumentByUserController,

    DocumentByFolderController,
  ],
  providers: [],
})
export class DocumentApplicationModule {}
