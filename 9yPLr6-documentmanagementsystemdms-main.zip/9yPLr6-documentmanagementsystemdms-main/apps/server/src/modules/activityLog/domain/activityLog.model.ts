import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Document } from '../../../modules/document/domain'

import { Folder } from '../../../modules/folder/domain'

@Entity()
export class ActivityLog {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  action?: string

  @Column({ nullable: true })
  timestamp?: string

  @Column({ nullable: true })
  userId?: string

  @ManyToOne(() => User, parent => parent.activityLogs)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({ nullable: true })
  documentId?: string

  @ManyToOne(() => Document, parent => parent.activityLogs)
  @JoinColumn({ name: 'documentId' })
  document?: Document

  @Column({ nullable: true })
  folderId?: string

  @ManyToOne(() => Folder, parent => parent.activityLogs)
  @JoinColumn({ name: 'folderId' })
  folder?: Folder

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
