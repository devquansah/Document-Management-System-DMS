import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ActivityLogDomainFacade } from './activityLog.domain.facade'
import { ActivityLog } from './activityLog.model'

@Module({
  imports: [TypeOrmModule.forFeature([ActivityLog]), DatabaseHelperModule],
  providers: [ActivityLogDomainFacade, ActivityLogDomainFacade],
  exports: [ActivityLogDomainFacade],
})
export class ActivityLogDomainModule {}
