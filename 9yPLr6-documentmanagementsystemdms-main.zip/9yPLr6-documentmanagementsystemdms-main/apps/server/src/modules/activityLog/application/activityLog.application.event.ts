export namespace ActivityLogApplicationEvent {
  export namespace ActivityLogCreated {
    export const key = 'activityLog.application.activityLog.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
