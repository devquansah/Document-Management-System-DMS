import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ActivityLogDomainFacade } from '@server/modules/activityLog/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ActivityLogApplicationEvent } from './activityLog.application.event'
import { ActivityLogCreateDto } from './activityLog.dto'

import { FolderDomainFacade } from '../../folder/domain'

@Controller('/v1/folders')
export class ActivityLogByFolderController {
  constructor(
    private folderDomainFacade: FolderDomainFacade,

    private activityLogDomainFacade: ActivityLogDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/folder/:folderId/activityLogs')
  async findManyFolderId(
    @Param('folderId') folderId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.folderDomainFacade.findOneByIdOrFail(folderId)

    const items = await this.activityLogDomainFacade.findManyByFolder(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/folder/:folderId/activityLogs')
  async createByFolderId(
    @Param('folderId') folderId: string,
    @Body() body: ActivityLogCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, folderId }

    const item = await this.activityLogDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ActivityLogApplicationEvent.ActivityLogCreated.Payload>(
      ActivityLogApplicationEvent.ActivityLogCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
