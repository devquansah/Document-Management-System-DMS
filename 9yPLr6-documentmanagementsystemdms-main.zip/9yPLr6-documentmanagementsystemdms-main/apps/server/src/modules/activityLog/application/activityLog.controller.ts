import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  ActivityLog,
  ActivityLogDomainFacade,
} from '@server/modules/activityLog/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ActivityLogApplicationEvent } from './activityLog.application.event'
import { ActivityLogCreateDto, ActivityLogUpdateDto } from './activityLog.dto'

@Controller('/v1/activityLogs')
export class ActivityLogController {
  constructor(
    private eventService: EventService,
    private activityLogDomainFacade: ActivityLogDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.activityLogDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ActivityLogCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.activityLogDomainFacade.create(body)

    await this.eventService.emit<ActivityLogApplicationEvent.ActivityLogCreated.Payload>(
      ActivityLogApplicationEvent.ActivityLogCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:activityLogId')
  async findOne(
    @Param('activityLogId') activityLogId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.activityLogDomainFacade.findOneByIdOrFail(
      activityLogId,
      queryOptions,
    )

    return item
  }

  @Patch('/:activityLogId')
  async update(
    @Param('activityLogId') activityLogId: string,
    @Body() body: ActivityLogUpdateDto,
  ) {
    const item =
      await this.activityLogDomainFacade.findOneByIdOrFail(activityLogId)

    const itemUpdated = await this.activityLogDomainFacade.update(
      item,
      body as Partial<ActivityLog>,
    )
    return itemUpdated
  }

  @Delete('/:activityLogId')
  async delete(@Param('activityLogId') activityLogId: string) {
    const item =
      await this.activityLogDomainFacade.findOneByIdOrFail(activityLogId)

    await this.activityLogDomainFacade.delete(item)

    return item
  }
}
