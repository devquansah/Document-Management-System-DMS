import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ActivityLogDomainModule } from '../domain'
import { ActivityLogController } from './activityLog.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ActivityLogByUserController } from './activityLogByUser.controller'

import { DocumentDomainModule } from '../../../modules/document/domain'

import { ActivityLogByDocumentController } from './activityLogByDocument.controller'

import { FolderDomainModule } from '../../../modules/folder/domain'

import { ActivityLogByFolderController } from './activityLogByFolder.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ActivityLogDomainModule,

    UserDomainModule,

    DocumentDomainModule,

    FolderDomainModule,
  ],
  controllers: [
    ActivityLogController,

    ActivityLogByUserController,

    ActivityLogByDocumentController,

    ActivityLogByFolderController,
  ],
  providers: [],
})
export class ActivityLogApplicationModule {}
