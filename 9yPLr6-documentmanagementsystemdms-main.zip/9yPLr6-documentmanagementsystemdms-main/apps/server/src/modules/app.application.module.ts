import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { RoleApplicationModule } from './role/application'

import { FolderApplicationModule } from './folder/application'

import { DocumentApplicationModule } from './document/application'

import { VersionApplicationModule } from './version/application'

import { MetadataApplicationModule } from './metadata/application'

import { PermissionApplicationModule } from './permission/application'

import { ShareApplicationModule } from './share/application'

import { ActivityLogApplicationModule } from './activityLog/application'

import { AlertApplicationModule } from './alert/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { BillingApplicationModule } from './billing/application'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,
    BillingApplicationModule,

    RoleApplicationModule,

    FolderApplicationModule,

    DocumentApplicationModule,

    VersionApplicationModule,

    MetadataApplicationModule,

    PermissionApplicationModule,

    ShareApplicationModule,

    ActivityLogApplicationModule,

    AlertApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
