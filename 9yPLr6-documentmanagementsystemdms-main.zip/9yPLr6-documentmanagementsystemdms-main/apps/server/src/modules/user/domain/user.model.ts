import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Notification } from '../../../modules/notification/domain'

import { Folder } from '../../../modules/folder/domain'

import { Document } from '../../../modules/document/domain'

import { Permission } from '../../../modules/permission/domain'

import { Share } from '../../../modules/share/domain'

import { ActivityLog } from '../../../modules/activityLog/domain'

import { Alert } from '../../../modules/alert/domain'

export enum UserStatus {
  VERIFIED = 'VERIFIED',
  CREATED = 'CREATED',
}

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true, unique: true })
  email?: string

  @Column({ nullable: true })
  name?: string

  @Column({ nullable: true })
  pictureUrl?: string

  @Column({ nullable: true, select: false })
  stripeCustomerId?: string

  @Column({ nullable: true, select: false })
  password?: string

  @Column({ enum: UserStatus, default: UserStatus.VERIFIED })
  status: UserStatus

  @OneToMany(() => Folder, child => child.createdBy)
  foldersAsCreatedBy?: Folder[]

  @OneToMany(() => Document, child => child.createdBy)
  documentsAsCreatedBy?: Document[]

  @OneToMany(() => Permission, child => child.user)
  permissions?: Permission[]

  @OneToMany(() => Share, child => child.sharedWith)
  sharesAsSharedWith?: Share[]

  @OneToMany(() => ActivityLog, child => child.user)
  activityLogs?: ActivityLog[]

  @OneToMany(() => Alert, child => child.user)
  alerts?: Alert[]

  @OneToMany(() => Notification, notification => notification.user)
  notifications?: Notification[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
