import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationRoleSubscriber } from './subscribers/notification.role.subscriber'

import { NotificationFolderSubscriber } from './subscribers/notification.folder.subscriber'

import { NotificationDocumentSubscriber } from './subscribers/notification.document.subscriber'

import { NotificationVersionSubscriber } from './subscribers/notification.version.subscriber'

import { NotificationMetadataSubscriber } from './subscribers/notification.metadata.subscriber'

import { NotificationPermissionSubscriber } from './subscribers/notification.permission.subscriber'

import { NotificationShareSubscriber } from './subscribers/notification.share.subscriber'

import { NotificationActivityLogSubscriber } from './subscribers/notification.activityLog.subscriber'

import { NotificationAlertSubscriber } from './subscribers/notification.alert.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationRoleSubscriber,

    NotificationFolderSubscriber,

    NotificationDocumentSubscriber,

    NotificationVersionSubscriber,

    NotificationMetadataSubscriber,

    NotificationPermissionSubscriber,

    NotificationShareSubscriber,

    NotificationActivityLogSubscriber,

    NotificationAlertSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
