import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Document } from '../../../modules/document/domain'

import { Permission } from '../../../modules/permission/domain'

import { ActivityLog } from '../../../modules/activityLog/domain'

@Entity()
export class Folder {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  name?: string

  @Column({ nullable: true })
  parentFolderId?: string

  @ManyToOne(() => Folder, parent => parent.foldersAsParentFolder)
  @JoinColumn({ name: 'parentFolderId' })
  parentFolder?: Folder

  @Column({ nullable: true })
  createdById?: string

  @ManyToOne(() => User, parent => parent.foldersAsCreatedBy)
  @JoinColumn({ name: 'createdById' })
  createdBy?: User

  @OneToMany(() => Folder, child => child.parentFolder)
  foldersAsParentFolder?: Folder[]

  @OneToMany(() => Document, child => child.folder)
  documents?: Document[]

  @OneToMany(() => Permission, child => child.folder)
  permissions?: Permission[]

  @OneToMany(() => ActivityLog, child => child.folder)
  activityLogs?: ActivityLog[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
