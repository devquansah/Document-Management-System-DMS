import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Folder } from './folder.model'

import { User } from '../../user/domain'

@Injectable()
export class FolderDomainFacade {
  constructor(
    @InjectRepository(Folder)
    private repository: Repository<Folder>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<Folder>): Promise<Folder> {
    return this.repository.save(values)
  }

  async update(item: Folder, values: Partial<Folder>): Promise<Folder> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Folder): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Folder> = {},
  ): Promise<Folder[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Folder> = {},
  ): Promise<Folder> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByParentFolder(
    item: Folder,
    queryOptions: RequestHelper.QueryOptions<Folder> = {},
  ): Promise<Folder[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('parentFolder')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        parentFolderId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByCreatedBy(
    item: User,
    queryOptions: RequestHelper.QueryOptions<Folder> = {},
  ): Promise<Folder[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('createdBy')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        createdById: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
