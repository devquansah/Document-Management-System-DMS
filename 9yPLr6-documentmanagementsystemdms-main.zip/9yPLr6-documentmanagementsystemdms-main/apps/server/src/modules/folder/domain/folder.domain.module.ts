import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { FolderDomainFacade } from './folder.domain.facade'
import { Folder } from './folder.model'

@Module({
  imports: [TypeOrmModule.forFeature([Folder]), DatabaseHelperModule],
  providers: [FolderDomainFacade, FolderDomainFacade],
  exports: [FolderDomainFacade],
})
export class FolderDomainModule {}
