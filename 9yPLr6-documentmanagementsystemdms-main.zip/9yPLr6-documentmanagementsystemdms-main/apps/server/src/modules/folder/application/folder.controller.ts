import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Folder, FolderDomainFacade } from '@server/modules/folder/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { FolderApplicationEvent } from './folder.application.event'
import { FolderCreateDto, FolderUpdateDto } from './folder.dto'

@Controller('/v1/folders')
export class FolderController {
  constructor(
    private eventService: EventService,
    private folderDomainFacade: FolderDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.folderDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: FolderCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.folderDomainFacade.create(body)

    await this.eventService.emit<FolderApplicationEvent.FolderCreated.Payload>(
      FolderApplicationEvent.FolderCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:folderId')
  async findOne(@Param('folderId') folderId: string, @Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.folderDomainFacade.findOneByIdOrFail(
      folderId,
      queryOptions,
    )

    return item
  }

  @Patch('/:folderId')
  async update(
    @Param('folderId') folderId: string,
    @Body() body: FolderUpdateDto,
  ) {
    const item = await this.folderDomainFacade.findOneByIdOrFail(folderId)

    const itemUpdated = await this.folderDomainFacade.update(
      item,
      body as Partial<Folder>,
    )
    return itemUpdated
  }

  @Delete('/:folderId')
  async delete(@Param('folderId') folderId: string) {
    const item = await this.folderDomainFacade.findOneByIdOrFail(folderId)

    await this.folderDomainFacade.delete(item)

    return item
  }
}
