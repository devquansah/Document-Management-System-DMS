export namespace FolderApplicationEvent {
  export namespace FolderCreated {
    export const key = 'folder.application.folder.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
