import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { FolderDomainModule } from '../domain'
import { FolderController } from './folder.controller'

import { FolderByFolderController } from './folderByFolder.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { FolderByUserController } from './folderByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, FolderDomainModule, UserDomainModule],
  controllers: [
    FolderController,

    FolderByFolderController,

    FolderByUserController,
  ],
  providers: [],
})
export class FolderApplicationModule {}
