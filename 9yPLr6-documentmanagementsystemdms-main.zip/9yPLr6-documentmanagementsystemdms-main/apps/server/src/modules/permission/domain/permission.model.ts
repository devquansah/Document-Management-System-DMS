import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Document } from '../../../modules/document/domain'

import { Folder } from '../../../modules/folder/domain'

@Entity()
export class Permission {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  canRead?: boolean

  @Column({ nullable: true })
  canWrite?: boolean

  @Column({ nullable: true })
  canShare?: boolean

  @Column({ nullable: true })
  userId?: string

  @ManyToOne(() => User, parent => parent.permissions)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({ nullable: true })
  documentId?: string

  @ManyToOne(() => Document, parent => parent.permissions)
  @JoinColumn({ name: 'documentId' })
  document?: Document

  @Column({ nullable: true })
  folderId?: string

  @ManyToOne(() => Folder, parent => parent.permissions)
  @JoinColumn({ name: 'folderId' })
  folder?: Folder

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
