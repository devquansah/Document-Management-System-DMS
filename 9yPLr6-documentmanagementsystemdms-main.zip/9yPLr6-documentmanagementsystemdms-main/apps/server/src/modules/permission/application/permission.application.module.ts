import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { PermissionDomainModule } from '../domain'
import { PermissionController } from './permission.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { PermissionByUserController } from './permissionByUser.controller'

import { DocumentDomainModule } from '../../../modules/document/domain'

import { PermissionByDocumentController } from './permissionByDocument.controller'

import { FolderDomainModule } from '../../../modules/folder/domain'

import { PermissionByFolderController } from './permissionByFolder.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    PermissionDomainModule,

    UserDomainModule,

    DocumentDomainModule,

    FolderDomainModule,
  ],
  controllers: [
    PermissionController,

    PermissionByUserController,

    PermissionByDocumentController,

    PermissionByFolderController,
  ],
  providers: [],
})
export class PermissionApplicationModule {}
