import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { PermissionDomainFacade } from '@server/modules/permission/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { PermissionApplicationEvent } from './permission.application.event'
import { PermissionCreateDto } from './permission.dto'

import { FolderDomainFacade } from '../../folder/domain'

@Controller('/v1/folders')
export class PermissionByFolderController {
  constructor(
    private folderDomainFacade: FolderDomainFacade,

    private permissionDomainFacade: PermissionDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/folder/:folderId/permissions')
  async findManyFolderId(
    @Param('folderId') folderId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.folderDomainFacade.findOneByIdOrFail(folderId)

    const items = await this.permissionDomainFacade.findManyByFolder(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/folder/:folderId/permissions')
  async createByFolderId(
    @Param('folderId') folderId: string,
    @Body() body: PermissionCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, folderId }

    const item = await this.permissionDomainFacade.create(valuesUpdated)

    await this.eventService.emit<PermissionApplicationEvent.PermissionCreated.Payload>(
      PermissionApplicationEvent.PermissionCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
