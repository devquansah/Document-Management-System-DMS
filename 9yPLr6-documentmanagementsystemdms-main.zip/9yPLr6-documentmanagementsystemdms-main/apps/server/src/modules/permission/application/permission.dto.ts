import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class PermissionCreateDto {
  @IsBoolean()
  @IsOptional()
  canRead?: boolean

  @IsBoolean()
  @IsOptional()
  canWrite?: boolean

  @IsBoolean()
  @IsOptional()
  canShare?: boolean

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  documentId?: string

  @IsString()
  @IsOptional()
  folderId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class PermissionUpdateDto {
  @IsBoolean()
  @IsOptional()
  canRead?: boolean

  @IsBoolean()
  @IsOptional()
  canWrite?: boolean

  @IsBoolean()
  @IsOptional()
  canShare?: boolean

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  documentId?: string

  @IsString()
  @IsOptional()
  folderId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
