import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ShareDomainFacade } from './share.domain.facade'
import { Share } from './share.model'

@Module({
  imports: [TypeOrmModule.forFeature([Share]), DatabaseHelperModule],
  providers: [ShareDomainFacade, ShareDomainFacade],
  exports: [ShareDomainFacade],
})
export class ShareDomainModule {}
