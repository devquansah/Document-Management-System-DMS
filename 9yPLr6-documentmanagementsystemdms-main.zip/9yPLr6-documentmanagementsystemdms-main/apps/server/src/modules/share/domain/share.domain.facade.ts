import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Share } from './share.model'

import { Document } from '../../document/domain'

import { User } from '../../user/domain'

@Injectable()
export class ShareDomainFacade {
  constructor(
    @InjectRepository(Share)
    private repository: Repository<Share>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<Share>): Promise<Share> {
    return this.repository.save(values)
  }

  async update(item: Share, values: Partial<Share>): Promise<Share> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Share): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Share> = {},
  ): Promise<Share[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Share> = {},
  ): Promise<Share> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByDocument(
    item: Document,
    queryOptions: RequestHelper.QueryOptions<Share> = {},
  ): Promise<Share[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('document')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        documentId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyBySharedWith(
    item: User,
    queryOptions: RequestHelper.QueryOptions<Share> = {},
  ): Promise<Share[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('sharedWith')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        sharedWithId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
