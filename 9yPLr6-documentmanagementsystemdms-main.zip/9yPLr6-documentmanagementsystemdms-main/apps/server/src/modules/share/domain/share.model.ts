import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Document } from '../../../modules/document/domain'

import { User } from '../../../modules/user/domain'

@Entity()
export class Share {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  expirationDate?: string

  @Column({ nullable: true })
  passwordProtected?: boolean

  @Column({ nullable: true })
  documentId?: string

  @ManyToOne(() => Document, parent => parent.shares)
  @JoinColumn({ name: 'documentId' })
  document?: Document

  @Column({ nullable: true })
  sharedWithId?: string

  @ManyToOne(() => User, parent => parent.sharesAsSharedWith)
  @JoinColumn({ name: 'sharedWithId' })
  sharedWith?: User

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
