import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ShareDomainFacade } from '@server/modules/share/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ShareApplicationEvent } from './share.application.event'
import { ShareCreateDto } from './share.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class ShareByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private shareDomainFacade: ShareDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/sharedWith/:sharedWithId/shares')
  async findManySharedWithId(
    @Param('sharedWithId') sharedWithId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(sharedWithId)

    const items = await this.shareDomainFacade.findManyBySharedWith(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/sharedWith/:sharedWithId/shares')
  async createBySharedWithId(
    @Param('sharedWithId') sharedWithId: string,
    @Body() body: ShareCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, sharedWithId }

    const item = await this.shareDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ShareApplicationEvent.ShareCreated.Payload>(
      ShareApplicationEvent.ShareCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
