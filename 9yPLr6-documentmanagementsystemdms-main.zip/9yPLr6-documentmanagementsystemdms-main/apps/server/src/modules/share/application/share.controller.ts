import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Share, ShareDomainFacade } from '@server/modules/share/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ShareApplicationEvent } from './share.application.event'
import { ShareCreateDto, ShareUpdateDto } from './share.dto'

@Controller('/v1/shares')
export class ShareController {
  constructor(
    private eventService: EventService,
    private shareDomainFacade: ShareDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.shareDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ShareCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.shareDomainFacade.create(body)

    await this.eventService.emit<ShareApplicationEvent.ShareCreated.Payload>(
      ShareApplicationEvent.ShareCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:shareId')
  async findOne(@Param('shareId') shareId: string, @Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.shareDomainFacade.findOneByIdOrFail(
      shareId,
      queryOptions,
    )

    return item
  }

  @Patch('/:shareId')
  async update(
    @Param('shareId') shareId: string,
    @Body() body: ShareUpdateDto,
  ) {
    const item = await this.shareDomainFacade.findOneByIdOrFail(shareId)

    const itemUpdated = await this.shareDomainFacade.update(
      item,
      body as Partial<Share>,
    )
    return itemUpdated
  }

  @Delete('/:shareId')
  async delete(@Param('shareId') shareId: string) {
    const item = await this.shareDomainFacade.findOneByIdOrFail(shareId)

    await this.shareDomainFacade.delete(item)

    return item
  }
}
