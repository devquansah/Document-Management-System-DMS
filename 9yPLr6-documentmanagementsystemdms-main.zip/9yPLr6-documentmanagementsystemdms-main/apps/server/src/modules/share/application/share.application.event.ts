export namespace ShareApplicationEvent {
  export namespace ShareCreated {
    export const key = 'share.application.share.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
