import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ShareDomainModule } from '../domain'
import { ShareController } from './share.controller'

import { DocumentDomainModule } from '../../../modules/document/domain'

import { ShareByDocumentController } from './shareByDocument.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ShareByUserController } from './shareByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ShareDomainModule,

    DocumentDomainModule,

    UserDomainModule,
  ],
  controllers: [
    ShareController,

    ShareByDocumentController,

    ShareByUserController,
  ],
  providers: [],
})
export class ShareApplicationModule {}
