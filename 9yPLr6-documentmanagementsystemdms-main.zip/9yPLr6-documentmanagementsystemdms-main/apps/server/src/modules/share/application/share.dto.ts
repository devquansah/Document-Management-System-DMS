import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ShareCreateDto {
  @IsString()
  @IsOptional()
  expirationDate?: string

  @IsBoolean()
  @IsOptional()
  passwordProtected?: boolean

  @IsString()
  @IsOptional()
  documentId?: string

  @IsString()
  @IsOptional()
  sharedWithId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class ShareUpdateDto {
  @IsString()
  @IsOptional()
  expirationDate?: string

  @IsBoolean()
  @IsOptional()
  passwordProtected?: boolean

  @IsString()
  @IsOptional()
  documentId?: string

  @IsString()
  @IsOptional()
  sharedWithId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
