import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ShareDomainFacade } from '@server/modules/share/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ShareApplicationEvent } from './share.application.event'
import { ShareCreateDto } from './share.dto'

import { DocumentDomainFacade } from '../../document/domain'

@Controller('/v1/documents')
export class ShareByDocumentController {
  constructor(
    private documentDomainFacade: DocumentDomainFacade,

    private shareDomainFacade: ShareDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/document/:documentId/shares')
  async findManyDocumentId(
    @Param('documentId') documentId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.documentDomainFacade.findOneByIdOrFail(documentId)

    const items = await this.shareDomainFacade.findManyByDocument(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/document/:documentId/shares')
  async createByDocumentId(
    @Param('documentId') documentId: string,
    @Body() body: ShareCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, documentId }

    const item = await this.shareDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ShareApplicationEvent.ShareCreated.Payload>(
      ShareApplicationEvent.ShareCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
