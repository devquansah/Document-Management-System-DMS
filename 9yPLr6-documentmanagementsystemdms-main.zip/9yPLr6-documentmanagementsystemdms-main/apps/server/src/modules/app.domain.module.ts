import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { RoleDomainModule } from './role/domain'

import { FolderDomainModule } from './folder/domain'

import { DocumentDomainModule } from './document/domain'

import { VersionDomainModule } from './version/domain'

import { MetadataDomainModule } from './metadata/domain'

import { PermissionDomainModule } from './permission/domain'

import { ShareDomainModule } from './share/domain'

import { ActivityLogDomainModule } from './activityLog/domain'

import { AlertDomainModule } from './alert/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    RoleDomainModule,

    FolderDomainModule,

    DocumentDomainModule,

    VersionDomainModule,

    MetadataDomainModule,

    PermissionDomainModule,

    ShareDomainModule,

    ActivityLogDomainModule,

    AlertDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
