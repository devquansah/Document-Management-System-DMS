'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Button, Space, Spin } from 'antd'
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function AlertsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [alerts, setAlerts] = useState<Model.Alert[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    if (userId) {
      Api.Alert.findManyByUserId(userId, { includes: ['user'] })
        .then(alerts => {
          setAlerts(alerts)
          setLoading(false)
        })
        .catch(error => {
          enqueueSnackbar('Failed to fetch alerts', { variant: 'error' })
          setLoading(false)
        })
    }
  }, [userId])

  const handleDelete = async (alertId: string) => {
    try {
      await Api.Alert.deleteOne(alertId)
      setAlerts(alerts.filter(alert => alert.id !== alertId))
      enqueueSnackbar('Alert deleted successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to delete alert', { variant: 'error' })
    }
  }

  const handleEdit = (alertId: string) => {
    // Navigate to the edit alert page if it exists
    router.push(`/alerts/edit/${alertId}`)
  }

  const handleCreate = () => {
    // Navigate to the create alert page if it exists
    router.push(`/alerts/create`)
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center" style={{ marginBottom: '20px' }}>
        <Col>
          <Title level={2}>Manage Alerts</Title>
          <Paragraph>View and manage your alerts here.</Paragraph>
        </Col>
      </Row>
      <Row justify="center" style={{ marginBottom: '20px' }}>
        <Col>
          <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
            Create Alert
          </Button>
        </Col>
      </Row>
      <Row justify="center">
        <Col span={24}>
          {loading ? (
            <Spin size="large" />
          ) : (
            <Row gutter={[16, 16]}>
              {alerts?.map(alert => (
                <Col key={alert.id} xs={24} sm={12} md={8} lg={6}>
                  <Card
                    title={alert.alertType}
                    extra={dayjs(alert.timestamp).format('YYYY-MM-DD HH:mm')}
                    actions={[
                      <EditOutlined
                        key="edit"
                        onClick={() => handleEdit(alert.id)}
                      />,
                      <DeleteOutlined
                        key="delete"
                        onClick={() => handleDelete(alert.id)}
                      />,
                    ]}
                  >
                    <Text>{alert.description}</Text>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </Col>
      </Row>
    </PageLayout>
  )
}
