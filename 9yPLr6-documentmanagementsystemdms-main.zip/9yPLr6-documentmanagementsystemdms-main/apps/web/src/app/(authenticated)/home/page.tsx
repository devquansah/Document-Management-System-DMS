'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Avatar } from 'antd'
import { UserOutlined, BellOutlined, FolderOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [user, setUser] = useState<Model.User | null>(null)
  const [notifications, setNotifications] = useState<Model.Notification[]>([])
  const [folders, setFolders] = useState<Model.Folder[]>([])

  useEffect(() => {
    if (userId) {
      Api.User.find(userId, {
        includes: ['notifications', 'foldersAsCreatedBy'],
      })
        .then(response => {
          setUser(response)
          setNotifications(response.notifications || [])
          setFolders(response.foldersAsCreatedBy || [])
        })
        .catch(error => {
          enqueueSnackbar('Failed to fetch user data', { variant: 'error' })
        })
    }
  }, [userId])

  return (
    <PageLayout layout="full-width">
      <Row justify="center" style={{ marginBottom: '20px' }}>
        <Col>
          <Title level={2}>Welcome to Your Dashboard</Title>
          <Paragraph>
            Here you can find your notifications and folders.
          </Paragraph>
        </Col>
      </Row>
      <Row justify="center" gutter={[16, 16]}>
        <Col xs={24} sm={12} md={8}>
          <Card title="User Info" bordered={false}>
            <Avatar size={64} icon={<UserOutlined />} src={user?.pictureUrl} />
            <Paragraph>
              <Text strong>Name:</Text> {user?.name}
            </Paragraph>
            <Paragraph>
              <Text strong>Email:</Text> {user?.email}
            </Paragraph>
            <Paragraph>
              <Text strong>Status:</Text> {user?.status}
            </Paragraph>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card title="Notifications" bordered={false} extra={<BellOutlined />}>
            {notifications.length > 0 ? (
              notifications.map(notification => (
                <Paragraph key={notification.id}>
                  <Text strong>{notification.title}</Text> -{' '}
                  {notification.message} (
                  {dayjs(notification.dateCreated).format('DD/MM/YYYY')})
                </Paragraph>
              ))
            ) : (
              <Paragraph>No notifications available</Paragraph>
            )}
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card title="Folders" bordered={false} extra={<FolderOutlined />}>
            {folders.length > 0 ? (
              folders.map(folder => (
                <Paragraph key={folder.id}>
                  <Text strong>{folder.name}</Text> - Created on{' '}
                  {dayjs(folder.dateCreated).format('DD/MM/YYYY')}
                </Paragraph>
              ))
            ) : (
              <Paragraph>No folders available</Paragraph>
            )}
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
