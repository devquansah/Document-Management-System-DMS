'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Button, Space } from 'antd'
import {
  FolderOutlined,
  FileOutlined,
  EditOutlined,
  DeleteOutlined,
} from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FolderDetailsPage() {
  const router = useRouter()
  const params = useParams<{ id: string }>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [folder, setFolder] = useState<Model.Folder | null>(null)
  const [documents, setDocuments] = useState<Model.Document[]>([])
  const [subFolders, setSubFolders] = useState<Model.Folder[]>([])

  useEffect(() => {
    const fetchFolderDetails = async () => {
      try {
        const folderData = await Api.Folder.findOne(params.id, {
          includes: ['createdBy', 'foldersAsParentFolder', 'documents'],
        })
        setFolder(folderData)
        setSubFolders(folderData.foldersAsParentFolder || [])
        setDocuments(folderData.documents || [])
      } catch (error) {
        enqueueSnackbar('Failed to fetch folder details', { variant: 'error' })
      }
    }

    if (params.id) {
      fetchFolderDetails()
    }
  }, [params.id])

  const handleEdit = () => {
    router.push(`/folders/${params.id}/edit`)
  }

  const handleDelete = async () => {
    try {
      await Api.Folder.deleteOne(params.id)
      enqueueSnackbar('Folder deleted successfully', { variant: 'success' })
      router.push('/folders')
    } catch (error) {
      enqueueSnackbar('Failed to delete folder', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12}>
          <Title level={2}>Folder Details</Title>
          <Paragraph>
            View detailed information about the selected folder, including its
            contents and related actions.
          </Paragraph>
          {folder && (
            <Card>
              <Title level={4}>{folder.name}</Title>
              <Text>Created by: {folder.createdBy?.name || 'Unknown'}</Text>
              <br />
              <Text>
                Created on: {dayjs(folder.dateCreated).format('MMMM D, YYYY')}
              </Text>
              <br />
              <Space>
                <Button icon={<EditOutlined />} onClick={handleEdit}>
                  Edit
                </Button>
                <Button icon={<DeleteOutlined />} danger onClick={handleDelete}>
                  Delete
                </Button>
              </Space>
            </Card>
          )}
          <Title level={4}>Subfolders</Title>
          <Row gutter={[16, 16]}>
            {subFolders?.map(subFolder => (
              <Col key={subFolder.id} xs={24} sm={12} md={8}>
                <Card
                  title={subFolder.name}
                  hoverable
                  onClick={() => router.push(`/folders/${subFolder.id}`)}
                  actions={[<FolderOutlined key="folder" />]}
                >
                  <Text>
                    Created on:{' '}
                    {dayjs(subFolder.dateCreated).format('MMMM D, YYYY')}
                  </Text>
                </Card>
              </Col>
            ))}
          </Row>
          <Title level={4}>Documents</Title>
          <Row gutter={[16, 16]}>
            {documents?.map(document => (
              <Col key={document.id} xs={24} sm={12} md={8}>
                <Card
                  title={document.title}
                  hoverable
                  onClick={() => router.push(`/documents/${document.id}`)}
                  actions={[<FileOutlined key="file" />]}
                >
                  <Text>
                    Created on:{' '}
                    {dayjs(document.dateCreated).format('MMMM D, YYYY')}
                  </Text>
                </Card>
              </Col>
            ))}
          </Row>
        </Col>
      </Row>
    </PageLayout>
  )
}
