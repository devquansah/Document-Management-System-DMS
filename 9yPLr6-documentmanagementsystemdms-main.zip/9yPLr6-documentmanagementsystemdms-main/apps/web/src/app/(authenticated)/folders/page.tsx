'use client'

import { useEffect, useState } from 'react'
import { Typography, Button, List, Modal, Input, Space, Row, Col } from 'antd'
import {
  FolderAddOutlined,
  DeleteOutlined,
  EditOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FolderManagementPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [folders, setFolders] = useState<Model.Folder[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false)
  const [newFolderName, setNewFolderName] = useState<string>('')
  const [editingFolder, setEditingFolder] = useState<Model.Folder | null>(null)

  useEffect(() => {
    if (userId) {
      fetchFolders()
    }
  }, [userId])

  const fetchFolders = async () => {
    try {
      const fetchedFolders = await Api.Folder.findManyByCreatedById(userId, {
        includes: ['createdBy', 'foldersAsParentFolder'],
      })
      setFolders(fetchedFolders)
    } catch (error) {
      enqueueSnackbar('Failed to fetch folders', { variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleCreateFolder = async () => {
    if (!newFolderName) return
    try {
      await Api.Folder.createOneByCreatedById(userId, { name: newFolderName })
      enqueueSnackbar('Folder created successfully', { variant: 'success' })
      fetchFolders()
      setIsModalVisible(false)
      setNewFolderName('')
    } catch (error) {
      enqueueSnackbar('Failed to create folder', { variant: 'error' })
    }
  }

  const handleEditFolder = async () => {
    if (!editingFolder || !newFolderName) return
    try {
      await Api.Folder.updateOne(editingFolder.id, { name: newFolderName })
      enqueueSnackbar('Folder updated successfully', { variant: 'success' })
      fetchFolders()
      setIsModalVisible(false)
      setNewFolderName('')
      setEditingFolder(null)
    } catch (error) {
      enqueueSnackbar('Failed to update folder', { variant: 'error' })
    }
  }

  const handleDeleteFolder = async (folderId: string) => {
    try {
      await Api.Folder.deleteOne(folderId)
      enqueueSnackbar('Folder deleted successfully', { variant: 'success' })
      fetchFolders()
    } catch (error) {
      enqueueSnackbar('Failed to delete folder', { variant: 'error' })
    }
  }

  const showModal = (folder?: Model.Folder) => {
    setIsModalVisible(true)
    if (folder) {
      setNewFolderName(folder.name || '')
      setEditingFolder(folder)
    }
  }

  const handleCancel = () => {
    setIsModalVisible(false)
    setNewFolderName('')
    setEditingFolder(null)
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12} xl={10}>
          <Title level={2}>Manage Folders</Title>
          <Text>
            Organize your folders within the Document Management System
          </Text>
          <Space style={{ marginTop: 20 }}>
            <Button
              type="primary"
              icon={<FolderAddOutlined />}
              onClick={() => showModal()}
            >
              Create Folder
            </Button>
          </Space>
          <List
            loading={loading}
            itemLayout="horizontal"
            dataSource={folders}
            renderItem={folder => (
              <List.Item
                actions={[
                  <Button
                    icon={<EditOutlined />}
                    onClick={() => showModal(folder)}
                  />,
                  <Button
                    icon={<DeleteOutlined />}
                    onClick={() => handleDeleteFolder(folder.id)}
                  />,
                ]}
              >
                <List.Item.Meta
                  title={folder.name}
                  description={`Created by: ${folder.createdBy?.name}`}
                />
              </List.Item>
            )}
            style={{ marginTop: 20 }}
          />
        </Col>
      </Row>
      <Modal
        title={editingFolder ? 'Edit Folder' : 'Create Folder'}
        visible={isModalVisible}
        onOk={editingFolder ? handleEditFolder : handleCreateFolder}
        onCancel={handleCancel}
      >
        <Input
          placeholder="Folder Name"
          value={newFolderName}
          onChange={e => setNewFolderName(e.target.value)}
        />
      </Modal>
    </PageLayout>
  )
}
