'use client'

import { useEffect, useState } from 'react'
import { Typography, List, Avatar, Spin, Row, Col } from 'antd'
import { UserOutlined, FileOutlined, FolderOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ActivityLogPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [activityLogs, setActivityLogs] = useState<Model.ActivityLog[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    if (userId) {
      Api.User.findOne(userId, {
        includes: [
          'activityLogs',
          'activityLogs.user',
          'activityLogs.document',
          'activityLogs.folder',
        ],
      })
        .then(user => {
          setActivityLogs(user.activityLogs || [])
        })
        .catch(error => {
          enqueueSnackbar('Failed to load activity logs', { variant: 'error' })
        })
        .finally(() => {
          setLoading(false)
        })
    }
  }, [userId])

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12} xl={10}>
          <Title level={2}>Activity Log</Title>
          <Paragraph>
            View the recent activities performed by the user.
          </Paragraph>
          {loading ? (
            <Spin size="large" />
          ) : (
            <List
              itemLayout="horizontal"
              dataSource={activityLogs}
              renderItem={item => (
                <List.Item>
                  <List.Item.Meta
                    avatar={
                      item.user ? (
                        <Avatar
                          src={item.user.pictureUrl}
                          icon={<UserOutlined />}
                        />
                      ) : item.document ? (
                        <Avatar icon={<FileOutlined />} />
                      ) : item.folder ? (
                        <Avatar icon={<FolderOutlined />} />
                      ) : (
                        <Avatar icon={<UserOutlined />} />
                      )
                    }
                    title={item.action}
                    description={
                      <>
                        <Text>
                          {dayjs(item.timestamp).format('YYYY-MM-DD HH:mm:ss')}
                        </Text>
                        <br />
                        <Text type="secondary">
                          {item.user ? `User: ${item.user.name}` : ''}
                          {item.document
                            ? `Document: ${item.document.title}`
                            : ''}
                          {item.folder ? `Folder: ${item.folder.name}` : ''}
                        </Text>
                      </>
                    }
                  />
                </List.Item>
              )}
            />
          )}
        </Col>
      </Row>
    </PageLayout>
  )
}
