'use client'

import { useState } from 'react'
import {
  Typography,
  Form,
  Input,
  Button,
  DatePicker,
  Checkbox,
  Row,
  Col,
} from 'antd'
import {
  UserOutlined,
  FileTextOutlined,
  CalendarOutlined,
  LockOutlined,
} from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ShareDocumentPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [loading, setLoading] = useState(false)

  const onFinish = async (values: any) => {
    setLoading(true)
    try {
      const shareValues: Partial<Model.Share> = {
        expirationDate: values.expirationDate
          ? dayjs(values.expirationDate).format('YYYY-MM-DD')
          : undefined,
        passwordProtected: values.passwordProtected,
        sharedWithId: values.sharedWithId,
        documentId: params.id,
      }
      await Api.Share.createOneByDocumentId(params.id, shareValues)
      enqueueSnackbar('Document shared successfully!', { variant: 'success' })
      router.push(`/documents/${params.id}`)
    } catch (error) {
      enqueueSnackbar('Failed to share document', { variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center" style={{ marginTop: '50px' }}>
        <Col xs={24} sm={20} md={16} lg={12} xl={8}>
          <Title level={2}>Share Document</Title>
          <Paragraph>
            Fill in the details below to share the document.
          </Paragraph>
          <Form layout="vertical" onFinish={onFinish}>
            <Form.Item
              name="sharedWithId"
              label={
                <Text>
                  <UserOutlined /> User ID
                </Text>
              }
              rules={[{ required: true, message: 'Please input the user ID!' }]}
            >
              <Input placeholder="Enter user ID" />
            </Form.Item>
            <Form.Item
              name="expirationDate"
              label={
                <Text>
                  <CalendarOutlined /> Expiration Date
                </Text>
              }
            >
              <DatePicker style={{ width: '100%' }} />
            </Form.Item>
            <Form.Item name="passwordProtected" valuePropName="checked">
              <Checkbox>
                <LockOutlined /> Password Protected
              </Checkbox>
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" loading={loading} block>
                Share Document
              </Button>
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </PageLayout>
  )
}
