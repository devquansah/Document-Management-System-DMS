'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Button, Spin, Form, Input, Space } from 'antd'
import { EditOutlined, DeleteOutlined, SaveOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function DocumentDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [document, setDocument] = useState<Model.Document | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    const fetchDocument = async () => {
      try {
        const documentId = params.id
        const documentFound = await Api.Document.findOne(documentId, {
          includes: ['createdBy', 'folder'],
        })
        setDocument(documentFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch document details', {
          variant: 'error',
        })
      } finally {
        setLoading(false)
      }
    }

    fetchDocument()
  }, [params.id])

  const handleEdit = () => {
    setEditing(true)
    form.setFieldsValue({
      title: document?.title,
      content: document?.content,
    })
  }

  const handleSave = async (values: any) => {
    try {
      const updatedDocument = await Api.Document.updateOne(params.id, values)
      setDocument(updatedDocument)
      setEditing(false)
      enqueueSnackbar('Document updated successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to update document', { variant: 'error' })
    }
  }

  const handleDelete = async () => {
    try {
      await Api.Document.deleteOne(params.id)
      enqueueSnackbar('Document deleted successfully', { variant: 'success' })
      router.push('/documents')
    } catch (error) {
      enqueueSnackbar('Failed to delete document', { variant: 'error' })
    }
  }

  if (loading) {
    return (
      <PageLayout layout="full-width">
        <Spin size="large" />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12}>
          <Title level={2}>Document Details</Title>
          <Paragraph>View and manage the details of the document.</Paragraph>
          {editing ? (
            <Form form={form} onFinish={handleSave} layout="vertical">
              <Form.Item
                name="title"
                label="Title"
                rules={[{ required: true, message: 'Please input the title!' }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="content"
                label="Content"
                rules={[
                  { required: true, message: 'Please input the content!' },
                ]}
              >
                <Input.TextArea rows={4} />
              </Form.Item>
              <Form.Item>
                <Space>
                  <Button
                    type="primary"
                    htmlType="submit"
                    icon={<SaveOutlined />}
                  >
                    Save
                  </Button>
                  <Button onClick={() => setEditing(false)}>Cancel</Button>
                </Space>
              </Form.Item>
            </Form>
          ) : (
            <>
              <Title level={4}>{document?.title}</Title>
              <Paragraph>{document?.content}</Paragraph>
              <Text type="secondary">
                Created by: {document?.createdBy?.name}
              </Text>
              <br />
              <Text type="secondary">
                Created on:{' '}
                {dayjs(document?.dateCreated).format('MMMM D, YYYY')}
              </Text>
              <br />
              <Space style={{ marginTop: '16px' }}>
                <Button
                  type="primary"
                  icon={<EditOutlined />}
                  onClick={handleEdit}
                >
                  Edit
                </Button>
                <Button
                  type="danger"
                  icon={<DeleteOutlined />}
                  onClick={handleDelete}
                >
                  Delete
                </Button>
              </Space>
            </>
          )}
        </Col>
      </Row>
    </PageLayout>
  )
}
