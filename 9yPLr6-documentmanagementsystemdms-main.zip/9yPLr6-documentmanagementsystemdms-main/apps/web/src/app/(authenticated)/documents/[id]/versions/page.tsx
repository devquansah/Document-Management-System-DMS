'use client'

import { useEffect, useState } from 'react'
import { Typography, Button, Table, Space, Modal, Form, Input } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function DocumentVersionsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [document, setDocument] = useState<Model.Document | null>(null)
  const [versions, setVersions] = useState<Model.Version[]>([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [editingVersion, setEditingVersion] = useState<Model.Version | null>(
    null,
  )

  useEffect(() => {
    const fetchDocument = async () => {
      try {
        const doc = await Api.Document.findOne(params.id, {
          includes: ['versions'],
        })
        setDocument(doc)
        setVersions(doc.versions || [])
      } catch (error) {
        enqueueSnackbar('Failed to fetch document', { variant: 'error' })
      }
    }
    fetchDocument()
  }, [params.id])

  const handleAddVersion = async (values: Partial<Model.Version>) => {
    try {
      const newVersion = await Api.Version.createOneByDocumentId(
        params.id,
        values,
      )
      setVersions([...versions, newVersion])
      setIsModalVisible(false)
      enqueueSnackbar('Version added successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to add version', { variant: 'error' })
    }
  }

  const handleUpdateVersion = async (values: Partial<Model.Version>) => {
    if (!editingVersion) return
    try {
      const updatedVersion = await Api.Version.updateOne(
        editingVersion.id,
        values,
      )
      setVersions(
        versions.map(v => (v.id === updatedVersion.id ? updatedVersion : v)),
      )
      setEditingVersion(null)
      setIsModalVisible(false)
      enqueueSnackbar('Version updated successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to update version', { variant: 'error' })
    }
  }

  const handleDeleteVersion = async (versionId: string) => {
    try {
      await Api.Version.deleteOne(versionId)
      setVersions(versions.filter(v => v.id !== versionId))
      enqueueSnackbar('Version deleted successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to delete version', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'Version Number',
      dataIndex: 'versionNumber',
      key: 'versionNumber',
    },
    {
      title: 'Content',
      dataIndex: 'content',
      key: 'content',
    },
    {
      title: 'Date Created',
      dataIndex: 'dateCreated',
      key: 'dateCreated',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Model.Version) => (
        <Space size="middle">
          <Button
            icon={<EditOutlined />}
            onClick={() => {
              setEditingVersion(record)
              setIsModalVisible(true)
            }}
          >
            Edit
          </Button>
          <Button
            icon={<DeleteOutlined />}
            onClick={() => handleDeleteVersion(record.id)}
          >
            Delete
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <Title level={2}>Document Versions</Title>
        <Text>View and manage different versions of the document.</Text>
      </div>
      <div style={{ textAlign: 'right', marginBottom: '20px' }}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={() => {
            setEditingVersion(null)
            setIsModalVisible(true)
          }}
        >
          Add Version
        </Button>
      </div>
      <Table dataSource={versions} columns={columns} rowKey="id" />
      <Modal
        title={editingVersion ? 'Edit Version' : 'Add Version'}
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form
          initialValues={
            editingVersion || { versionNumber: versions.length + 1 }
          }
          onFinish={editingVersion ? handleUpdateVersion : handleAddVersion}
        >
          <Form.Item
            name="versionNumber"
            label="Version Number"
            rules={[
              { required: true, message: 'Please input the version number!' },
            ]}
          >
            <Input type="number" />
          </Form.Item>
          <Form.Item
            name="content"
            label="Content"
            rules={[{ required: true, message: 'Please input the content!' }]}
          >
            <Input.TextArea rows={4} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              {editingVersion ? 'Update' : 'Add'}
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
