'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Button, Spin } from 'antd'
import { FolderOutlined, FileOutlined, PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function DocumentRepositoryPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [folders, setFolders] = useState<Model.Folder[]>([])
  const [documents, setDocuments] = useState<Model.Document[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    if (userId) {
      Api.User.findOne(userId, {
        includes: ['foldersAsCreatedBy.documentsAsCreatedBy'],
      })
        .then((user: Model.User) => {
          setFolders(user.foldersAsCreatedBy || [])
          setDocuments(user.documentsAsCreatedBy || [])
        })
        .catch(error => {
          enqueueSnackbar('Failed to load data', { variant: 'error' })
        })
        .finally(() => {
          setLoading(false)
        })
    }
  }, [userId])

  const handleCreateFolder = async () => {
    if (userId) {
      try {
        const newFolder = await Api.Folder.createOneByCreatedById(userId, {
          name: 'New Folder',
        })
        setFolders([...folders, newFolder])
        enqueueSnackbar('Folder created successfully', { variant: 'success' })
      } catch (error) {
        enqueueSnackbar('Failed to create folder', { variant: 'error' })
      }
    }
  }

  const handleCreateDocument = async () => {
    if (userId) {
      try {
        const newDocument = await Api.Document.createOneByCreatedById(userId, {
          title: 'New Document',
        })
        setDocuments([...documents, newDocument])
        enqueueSnackbar('Document created successfully', { variant: 'success' })
      } catch (error) {
        enqueueSnackbar('Failed to create document', { variant: 'error' })
      }
    }
  }

  return (
    <PageLayout layout="full-width">
      <Title level={2}>Document Repository</Title>
      <Text>
        A centralized repository for storing, managing, and sharing documents.
      </Text>
      <div style={{ margin: '20px 0' }}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleCreateFolder}
          style={{ marginRight: '10px' }}
        >
          Create Folder
        </Button>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleCreateDocument}
        >
          Create Document
        </Button>
      </div>
      {loading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]}>
          {folders.map(folder => (
            <Col key={folder.id} xs={24} sm={12} md={8} lg={6}>
              <Card
                title={folder.name}
                hoverable
                onClick={() => router.push(`/folders/${folder.id}`)}
                style={{ textAlign: 'center' }}
              >
                <FolderOutlined style={{ fontSize: '24px' }} />
              </Card>
            </Col>
          ))}
          {documents.map(document => (
            <Col key={document.id} xs={24} sm={12} md={8} lg={6}>
              <Card
                title={document.title}
                hoverable
                onClick={() => router.push(`/documents/${document.id}`)}
                style={{ textAlign: 'center' }}
              >
                <FileOutlined style={{ fontSize: '24px' }} />
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
