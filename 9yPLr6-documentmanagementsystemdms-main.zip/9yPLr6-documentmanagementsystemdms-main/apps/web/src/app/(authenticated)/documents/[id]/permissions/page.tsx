'use client'

import { useEffect, useState } from 'react'
import {
  Typography,
  Table,
  Button,
  Space,
  Modal,
  Checkbox,
  Form,
  Input,
} from 'antd'
import { EditOutlined, DeleteOutlined, PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function DocumentPermissionsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [document, setDocument] = useState<Model.Document | null>(null)
  const [permissions, setPermissions] = useState<Model.Permission[]>([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [editingPermission, setEditingPermission] =
    useState<Model.Permission | null>(null)
  const [form] = Form.useForm()

  useEffect(() => {
    const fetchDocumentAndPermissions = async () => {
      try {
        const documentData = await Api.Document.findOne(params.id, {
          includes: ['permissions.user'],
        })
        setDocument(documentData)
        setPermissions(documentData.permissions || [])
      } catch (error) {
        enqueueSnackbar('Failed to load document and permissions', {
          variant: 'error',
        })
      }
    }
    fetchDocumentAndPermissions()
  }, [params.id])

  const handleEdit = (permission: Model.Permission) => {
    setEditingPermission(permission)
    form.setFieldsValue({
      canRead: permission.canRead,
      canWrite: permission.canWrite,
      canShare: permission.canShare,
      userId: permission.userId,
    })
    setIsModalVisible(true)
  }

  const handleDelete = async (permissionId: string) => {
    try {
      await Api.Permission.deleteOne(permissionId)
      setPermissions(
        permissions.filter(permission => permission.id !== permissionId),
      )
      enqueueSnackbar('Permission deleted successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to delete permission', { variant: 'error' })
    }
  }

  const handleAdd = () => {
    setEditingPermission(null)
    form.resetFields()
    setIsModalVisible(true)
  }

  const handleModalOk = async () => {
    try {
      const values = form.getFieldsValue()
      if (editingPermission) {
        const updatedPermission = await Api.Permission.updateOne(
          editingPermission.id,
          values,
        )
        setPermissions(
          permissions.map(permission =>
            permission.id === updatedPermission.id
              ? updatedPermission
              : permission,
          ),
        )
        enqueueSnackbar('Permission updated successfully', {
          variant: 'success',
        })
      } else {
        const newPermission = await Api.Permission.createOneByDocumentId(
          params.id,
          values,
        )
        setPermissions([...permissions, newPermission])
        enqueueSnackbar('Permission created successfully', {
          variant: 'success',
        })
      }
      setIsModalVisible(false)
    } catch (error) {
      enqueueSnackbar('Failed to save permission', { variant: 'error' })
    }
  }

  const handleModalCancel = () => {
    setIsModalVisible(false)
  }

  const columns = [
    {
      title: 'User',
      dataIndex: 'user',
      key: 'user',
      render: (user: Model.User) => user?.name || user?.email,
    },
    {
      title: 'Can Read',
      dataIndex: 'canRead',
      key: 'canRead',
      render: (canRead: boolean) => <Checkbox checked={canRead} disabled />,
    },
    {
      title: 'Can Write',
      dataIndex: 'canWrite',
      key: 'canWrite',
      render: (canWrite: boolean) => <Checkbox checked={canWrite} disabled />,
    },
    {
      title: 'Can Share',
      dataIndex: 'canShare',
      key: 'canShare',
      render: (canShare: boolean) => <Checkbox checked={canShare} disabled />,
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (text: any, record: Model.Permission) => (
        <Space size="middle">
          <Button icon={<EditOutlined />} onClick={() => handleEdit(record)}>
            Edit
          </Button>
          <Button
            icon={<DeleteOutlined />}
            onClick={() => handleDelete(record.id)}
          >
            Delete
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <div style={{ textAlign: 'center', padding: '20px' }}>
        <Title level={2}>Manage Permissions for Document</Title>
        <Text>{document?.title}</Text>
      </div>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAdd}
          style={{ marginBottom: '20px' }}
        >
          Add Permission
        </Button>
        <Table dataSource={permissions} columns={columns} rowKey="id" />
      </div>
      <Modal
        title={editingPermission ? 'Edit Permission' : 'Add Permission'}
        visible={isModalVisible}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            name="userId"
            label="User ID"
            rules={[{ required: true, message: 'Please input the User ID!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item name="canRead" valuePropName="checked">
            <Checkbox>Can Read</Checkbox>
          </Form.Item>
          <Form.Item name="canWrite" valuePropName="checked">
            <Checkbox>Can Write</Checkbox>
          </Form.Item>
          <Form.Item name="canShare" valuePropName="checked">
            <Checkbox>Can Share</Checkbox>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
