import { Notification } from '../notification'

import { Folder } from '../folder'

import { Document } from '../document'

import { Permission } from '../permission'

import { Share } from '../share'

import { ActivityLog } from '../activityLog'

import { Alert } from '../alert'

export enum UserStatus {
  CREATED = 'CREATED',
  VERIFIED = 'VERIFIED',
}
export class User {
  id: string
  email?: string
  status: UserStatus
  name?: string
  pictureUrl?: string
  password?: string
  dateCreated: string
  dateUpdated: string
  notifications?: Notification[]

  foldersAsCreatedBy?: Folder[]

  documentsAsCreatedBy?: Document[]

  permissions?: Permission[]

  sharesAsSharedWith?: Share[]

  activityLogs?: ActivityLog[]

  alerts?: Alert[]
}
