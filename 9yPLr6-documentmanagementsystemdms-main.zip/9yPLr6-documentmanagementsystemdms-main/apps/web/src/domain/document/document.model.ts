import { User } from '../user'

import { Folder } from '../folder'

import { Version } from '../version'

import { Metadata } from '../metadata'

import { Permission } from '../permission'

import { Share } from '../share'

import { ActivityLog } from '../activityLog'

export class Document {
  id: string

  title?: string

  content?: string

  versionId?: string

  createdById?: string

  createdBy?: User

  folderId?: string

  folder?: Folder

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  versions?: Version[]

  metadatas?: Metadata[]

  permissions?: Permission[]

  shares?: Share[]

  activityLogs?: ActivityLog[]
}
