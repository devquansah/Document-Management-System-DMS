import { Document } from '../document'

export class Version {
  id: string

  versionNumber?: number

  content?: string

  documentId?: string

  document?: Document

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
