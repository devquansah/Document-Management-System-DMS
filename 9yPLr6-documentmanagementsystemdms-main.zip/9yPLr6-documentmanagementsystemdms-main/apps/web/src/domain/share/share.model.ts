import { Document } from '../document'

import { User } from '../user'

export class Share {
  id: string

  expirationDate?: string

  passwordProtected?: boolean

  documentId?: string

  document?: Document

  sharedWithId?: string

  sharedWith?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
