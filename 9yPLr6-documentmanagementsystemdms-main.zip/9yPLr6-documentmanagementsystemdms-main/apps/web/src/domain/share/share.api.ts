import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Share } from './share.model'

export class ShareApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Share>,
  ): Promise<Share[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/shares${buildOptions}`)
  }

  static findOne(
    shareId: string,
    queryOptions?: ApiHelper.QueryOptions<Share>,
  ): Promise<Share> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/shares/${shareId}${buildOptions}`)
  }

  static createOne(values: Partial<Share>): Promise<Share> {
    return HttpService.api.post(`/v1/shares`, values)
  }

  static updateOne(shareId: string, values: Partial<Share>): Promise<Share> {
    return HttpService.api.patch(`/v1/shares/${shareId}`, values)
  }

  static deleteOne(shareId: string): Promise<void> {
    return HttpService.api.delete(`/v1/shares/${shareId}`)
  }

  static findManyByDocumentId(
    documentId: string,
    queryOptions?: ApiHelper.QueryOptions<Share>,
  ): Promise<Share[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/documents/document/${documentId}/shares${buildOptions}`,
    )
  }

  static createOneByDocumentId(
    documentId: string,
    values: Partial<Share>,
  ): Promise<Share> {
    return HttpService.api.post(
      `/v1/documents/document/${documentId}/shares`,
      values,
    )
  }

  static findManyBySharedWithId(
    sharedWithId: string,
    queryOptions?: ApiHelper.QueryOptions<Share>,
  ): Promise<Share[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/sharedWith/${sharedWithId}/shares${buildOptions}`,
    )
  }

  static createOneBySharedWithId(
    sharedWithId: string,
    values: Partial<Share>,
  ): Promise<Share> {
    return HttpService.api.post(
      `/v1/users/sharedWith/${sharedWithId}/shares`,
      values,
    )
  }
}
