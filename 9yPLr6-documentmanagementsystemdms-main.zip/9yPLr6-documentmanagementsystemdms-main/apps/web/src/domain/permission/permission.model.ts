import { User } from '../user'

import { Document } from '../document'

import { Folder } from '../folder'

export class Permission {
  id: string

  canRead?: boolean

  canWrite?: boolean

  canShare?: boolean

  userId?: string

  user?: User

  documentId?: string

  document?: Document

  folderId?: string

  folder?: Folder

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
