import { User } from '../user'

import { Document } from '../document'

import { Permission } from '../permission'

import { ActivityLog } from '../activityLog'

export class Folder {
  id: string

  name?: string

  parentFolderId?: string

  parentFolder?: Folder

  createdById?: string

  createdBy?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  foldersAsParentFolder?: Folder[]

  documents?: Document[]

  permissions?: Permission[]

  activityLogs?: ActivityLog[]
}
