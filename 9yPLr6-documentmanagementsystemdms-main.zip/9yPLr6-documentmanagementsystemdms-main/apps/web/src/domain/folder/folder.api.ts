import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Folder } from './folder.model'

export class FolderApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Folder>,
  ): Promise<Folder[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/folders${buildOptions}`)
  }

  static findOne(
    folderId: string,
    queryOptions?: ApiHelper.QueryOptions<Folder>,
  ): Promise<Folder> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/folders/${folderId}${buildOptions}`)
  }

  static createOne(values: Partial<Folder>): Promise<Folder> {
    return HttpService.api.post(`/v1/folders`, values)
  }

  static updateOne(folderId: string, values: Partial<Folder>): Promise<Folder> {
    return HttpService.api.patch(`/v1/folders/${folderId}`, values)
  }

  static deleteOne(folderId: string): Promise<void> {
    return HttpService.api.delete(`/v1/folders/${folderId}`)
  }

  static findManyByParentFolderId(
    parentFolderId: string,
    queryOptions?: ApiHelper.QueryOptions<Folder>,
  ): Promise<Folder[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/folders/parentFolder/${parentFolderId}/folders${buildOptions}`,
    )
  }

  static createOneByParentFolderId(
    parentFolderId: string,
    values: Partial<Folder>,
  ): Promise<Folder> {
    return HttpService.api.post(
      `/v1/folders/parentFolder/${parentFolderId}/folders`,
      values,
    )
  }

  static findManyByCreatedById(
    createdById: string,
    queryOptions?: ApiHelper.QueryOptions<Folder>,
  ): Promise<Folder[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/createdBy/${createdById}/folders${buildOptions}`,
    )
  }

  static createOneByCreatedById(
    createdById: string,
    values: Partial<Folder>,
  ): Promise<Folder> {
    return HttpService.api.post(
      `/v1/users/createdBy/${createdById}/folders`,
      values,
    )
  }
}
