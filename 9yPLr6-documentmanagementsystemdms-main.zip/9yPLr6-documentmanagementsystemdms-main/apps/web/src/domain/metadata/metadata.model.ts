import { Document } from '../document'

export class Metadata {
  id: string

  key?: string

  value?: string

  documentId?: string

  document?: Document

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
