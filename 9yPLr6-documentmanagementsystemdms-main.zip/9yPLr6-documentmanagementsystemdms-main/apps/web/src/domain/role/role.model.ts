export class Role {
  id: string

  name?: string

  description?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
