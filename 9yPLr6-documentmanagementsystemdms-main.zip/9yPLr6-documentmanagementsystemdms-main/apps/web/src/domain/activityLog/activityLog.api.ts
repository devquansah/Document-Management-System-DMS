import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { ActivityLog } from './activityLog.model'

export class ActivityLogApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<ActivityLog>,
  ): Promise<ActivityLog[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/activityLogs${buildOptions}`)
  }

  static findOne(
    activityLogId: string,
    queryOptions?: ApiHelper.QueryOptions<ActivityLog>,
  ): Promise<ActivityLog> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/activityLogs/${activityLogId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<ActivityLog>): Promise<ActivityLog> {
    return HttpService.api.post(`/v1/activityLogs`, values)
  }

  static updateOne(
    activityLogId: string,
    values: Partial<ActivityLog>,
  ): Promise<ActivityLog> {
    return HttpService.api.patch(`/v1/activityLogs/${activityLogId}`, values)
  }

  static deleteOne(activityLogId: string): Promise<void> {
    return HttpService.api.delete(`/v1/activityLogs/${activityLogId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<ActivityLog>,
  ): Promise<ActivityLog[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/activityLogs${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<ActivityLog>,
  ): Promise<ActivityLog> {
    return HttpService.api.post(`/v1/users/user/${userId}/activityLogs`, values)
  }

  static findManyByDocumentId(
    documentId: string,
    queryOptions?: ApiHelper.QueryOptions<ActivityLog>,
  ): Promise<ActivityLog[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/documents/document/${documentId}/activityLogs${buildOptions}`,
    )
  }

  static createOneByDocumentId(
    documentId: string,
    values: Partial<ActivityLog>,
  ): Promise<ActivityLog> {
    return HttpService.api.post(
      `/v1/documents/document/${documentId}/activityLogs`,
      values,
    )
  }

  static findManyByFolderId(
    folderId: string,
    queryOptions?: ApiHelper.QueryOptions<ActivityLog>,
  ): Promise<ActivityLog[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/folders/folder/${folderId}/activityLogs${buildOptions}`,
    )
  }

  static createOneByFolderId(
    folderId: string,
    values: Partial<ActivityLog>,
  ): Promise<ActivityLog> {
    return HttpService.api.post(
      `/v1/folders/folder/${folderId}/activityLogs`,
      values,
    )
  }
}
