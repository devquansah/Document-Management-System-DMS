import { User } from '../user'

import { Document } from '../document'

import { Folder } from '../folder'

export class ActivityLog {
  id: string

  action?: string

  timestamp?: string

  userId?: string

  user?: User

  documentId?: string

  document?: Document

  folderId?: string

  folder?: Folder

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
