import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'
import {
  BillingPayment as BillingPaymentModel,
  BillingProduct as BillingProductModel,
  BillingSubscription as BillingSubscriptionModel,
} from './billing/billing.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Role as RoleModel } from './role/role.model'

import { Folder as FolderModel } from './folder/folder.model'

import { Document as DocumentModel } from './document/document.model'

import { Version as VersionModel } from './version/version.model'

import { Metadata as MetadataModel } from './metadata/metadata.model'

import { Permission as PermissionModel } from './permission/permission.model'

import { Share as ShareModel } from './share/share.model'

import { ActivityLog as ActivityLogModel } from './activityLog/activityLog.model'

import { Alert as AlertModel } from './alert/alert.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}
  export class BillingProduct extends BillingProductModel {}
  export class BillingPayment extends BillingPaymentModel {}
  export class BillingSubscription extends BillingSubscriptionModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Role extends RoleModel {}

  export class Folder extends FolderModel {}

  export class Document extends DocumentModel {}

  export class Version extends VersionModel {}

  export class Metadata extends MetadataModel {}

  export class Permission extends PermissionModel {}

  export class Share extends ShareModel {}

  export class ActivityLog extends ActivityLogModel {}

  export class Alert extends AlertModel {}
}
